<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>phpForm</title>
    <link rel="stylesheet" href="stylesheet.css">
</head>
<body>
    <form action="post.php" method="post">
        <div class="input field">Nombre<input type="text" name="nom"></div>
        <div class="input field">Apellido<input type="text" name="ape"></div>
        <div class="input field">Usuario<input type="text" name="usu"></div>
        <div class="input field">Contraseña<input type="password" name="pw"></div>
        <div class="input field">Perfil
        <select name="perfil">
            <option value="Admin">Admin</option>
            <option value="Cliente">Cliente</option>
            <option value="Operador">Operador</option>
            </select>
        </div>
        <div class="input"><input type="radio" name="deporte"> Deporte</div>
        <div class="input"><input type="radio" name="lectura"> Lectura</div>
        <div class="input"><input type="radio" name="arte"> Arte</div>
        <div class="input"><input type="checkbox" name="terms"> ¿Acepta términos?</div>
        <button type="reset" name="reset">Cancelar</button>
        <button type="submit" name="enviar">Enviar</button>
    </form>
</body>
</html>