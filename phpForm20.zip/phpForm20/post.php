<?php
#validacion y variables

var_dump($_POST);
$nom = $_POST["nom"];
$ape = $_POST["ape"];
$usu = $_POST["usu"];
$pw = $_POST["pw"];
$perfil = $_POST["perfil"];
$deporte = isset($_POST["deporte"]);
$lectura = isset($_POST["lectura"]);
$arte = isset($_POST["arte"]);
$terms = isset($_POST["terms"]);

if (($usu=="pepe"&&$pw=="1234"&&$perfil=="Admin")||($usu=="pepito"&&$pw=="abc456"&&$perfil=="Cliente")||($usu=="juancito"&&$pw=="qwerty13"&&$perfil=="Operador")) {
    echo("El usuario es válido");
}else{
    echo("El usuario es inválido ♿");
}
if (strlen($pw)<5) {
    echo("Contraseña Débil");
}elseif(strlen($pw)<7){
    echo "Contraseña Media";
}else{
    echo "Contraseña Fuerte";
}

if ($terms) {
    echo('<a href="condiciones.php">VER CONDICIONES</a>');
}
#redirect

if ($deporte) {
    echo('<iframe width="560" height="315" src="https://www.youtube.com/embed/wZnCcqm_g-E" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
}
if ($lectura){
    echo('<embed src="https://www2.ohchr.org/english/issues/water/docs/Right_to_Water.pdf" width="100%" height="600px" />');
}

if ($arte){
    echo('<img src="https://images.saatchiart.com/saatchi/732690/art/8168064/7234149-HSC00001-6.jpg">');
}
echo(strlen($pw));

?>

